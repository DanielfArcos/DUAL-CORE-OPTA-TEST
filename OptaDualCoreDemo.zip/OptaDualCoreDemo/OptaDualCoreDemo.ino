#include "Arduino.h"
#include "stm32h7xx_hal.h"

// ==========================================
// ESTRUTURA DE DADOS COMPARTILHADA
// ==========================================
// Alinhado em 32 bytes para evitar acidentalmente desalinhamentos
// em caso de cache no M7 (SRAM4 na arquitetura H7 mbed já é muitas vezes tratada 
// como non-cacheable automaticamente para uso do IPC/OpenAMP).
struct alignas(32) SharedData {
  float voltage;
  float current;
  bool newData;
  char m4_message[64];
  bool hasMessage;
};

// ==========================================
// ACESSO À MEMÓRIA RAM COMPARTILHADA
// ==========================================
// A região de memória SRAM_D3 (SRAM4) do STM32H747 começa em 0x38000000. 
// Ela é simultaneamente acessível por ambos os núcleos (Cortex-M7 e Cortex-M4).
volatile SharedData* sharedData = (volatile SharedData*)0x38000000;

// Mutex em Hardware (HSEM). STM32H7 possui 32 semáforos integrados (0 a 31).
// Pega-se o 31 por precaução de conflito zero no OS.
#define HSEM_ID_SHARED_DATA   31  

// Pinos dos LEDs no Arduino Opta
#define PIN_LED_M4  LED_D0
#define PIN_LED_M7  LED_D1

// =========================================================================
// ================== CÓDIGO DO CORE M7 (COMUNICAÇÃO) ======================
// O M7 lida com I/Os pesados, conexão USB, Network/ModbusTCP, Servidor HTTP
// =========================================================================
#ifdef CORE_CM7

void setup() {
  // Inicialização do fluxo simultâneo, inicia o M4 efetivamente
  bootM4();
  
  Serial.begin(115200);
  pinMode(PIN_LED_M7, OUTPUT);

  // Zera a memória rodando apenas no M7 uma vez
  if (HAL_HSEM_FastTake(HSEM_ID_SHARED_DATA) == HAL_OK) {
     sharedData->voltage = 0.0;
     sharedData->current = 0.0;
     sharedData->newData = false;
     sharedData->hasMessage = false;
     for(int i=0; i<64; i++) sharedData->m4_message[i] = '\0';
     
     // Solta o mutex
     HAL_HSEM_Release(HSEM_ID_SHARED_DATA, 0);
  }

  // Espera a porta Serial Conectar no Desktop para visualizarmos a introdução
  delay(2000);
  Serial.println("\n");
  Serial.println("================================================");
  Serial.println("  SISTEMA EMBARCADO DUAL-CORE INICIADO (OPTA) ");
  Serial.println("  - CORE M7: Interface, Rede, Logs (Blink em D1)");
  Serial.println("  - CORE M4: Sensores, Tempo Real (Blink em D0)");
  Serial.println("================================================\n");
}

void loop() {
  // 1. Pisca o LED do M7 lentamente (500ms / 1Hz) confirmando sua execução
  static unsigned long lastBlinkM7 = 0;
  if (millis() - lastBlinkM7 >= 500) {
    digitalWrite(PIN_LED_M7, !digitalRead(PIN_LED_M7));
    lastBlinkM7 = millis();
  }

  // 2. Leitura periódica dos dados em memória
  static unsigned long lastRead = 0;
  if (millis() - lastRead >= 500) { // Pode exibir a cada 500ms
     
     // * PROTEÇÃO DE ACESSO (LOCK MUTEX) *
     if (HAL_HSEM_FastTake(HSEM_ID_SHARED_DATA) == HAL_OK) {
        
        // Verifica mensagens internas de status originárias do M4
        if (sharedData->hasMessage) {
           Serial.print("[M4] ");
           Serial.println((char*)sharedData->m4_message);
           sharedData->hasMessage = false;
        }

        // Verifica novos dados processados
        if (sharedData->newData) {
           Serial.print("[M7] Enviando dados: Tensao=");
           Serial.print(sharedData->voltage);
           Serial.print("V Corrente=");
           Serial.print(sharedData->current);
           Serial.println("A");
           
           // Limpa o flag
           sharedData->newData = false;
        }
        
        // * LIBERAÇÃO DO ACESSO (UNLOCK MUTEX) *
        HAL_HSEM_Release(HSEM_ID_SHARED_DATA, 0);
     }
     lastRead = millis();
  }

  // 3. * CRÍTICO *: TESTE DE INDEPENDÊNCIA DE CORES (REQ #4)
  // A cada 10 segundos, faremos o M7 "travar / pendurar", o M4 NÃO pode parar!
  static unsigned long lastFreeze = 0;
  if (millis() - lastFreeze >= 10000) {
     Serial.println("\n[M7] >>> SIMULANDO UM PROCESSO LONGO / TRAVAMENTO NO M7 (2 SEG) <<<");
     Serial.println("[M7] >>> OBSERVE: O LED D0 (CORE M4) CONTINUARA PISCANDO NORMALMENTE <<<");
     
     // Paralisia simulada
     delay(2000); 
     
     Serial.println("[M7] >>> DE VOLTA! <<< \n");
     lastFreeze = millis();
  }
}

#endif // CORE_CM7


// =========================================================================
// ================== CÓDIGO DO CORE M4 (TEMPO REAL) =======================
// O M4 lida com loops fechados e matemática sem interrupções por redes TCP
// =========================================================================
#ifdef CORE_CM4

#include <math.h>

void setup() {
  pinMode(PIN_LED_M4, OUTPUT);
}

void loop() {
  static unsigned long lastRealTimeTask = 0;
  static unsigned long lastStatusMsg = 0;
  static float angulo = 0.0;
  
  unsigned long now = millis();
  
  // Tarefa Cíclica e Determinística de 100ms
  if (now - lastRealTimeTask >= 100) {
    lastRealTimeTask = now;
    
    // 1. INDICADOR VISUAL M4: Frequência Super Rápida que NUNCA Gagueja
    digitalWrite(PIN_LED_M4, !digitalRead(PIN_LED_M4));

    // 2. PROCESSAMENTO (Simulação) SEGUIDO DE TRANSFERÊNCIA BLINDADA (MUTEX)
    if (HAL_HSEM_FastTake(HSEM_ID_SHARED_DATA) == HAL_OK) {
        
        // Simulação matemática de ondas no maquinário
        sharedData->voltage = 220.0 + (sin(angulo) * 12.0); // Flutua em +-12V
        sharedData->current = 10.0 + (cos(angulo) * 3.5);   // Flutua em +-3.5A
        sharedData->newData = true;
        
        angulo += 0.1;
        
        // Sempre deve liberar após terminar de redigitar
        HAL_HSEM_Release(HSEM_ID_SHARED_DATA, 0);
    }
  }

  // Exemplo de envio ocasional independente de Status Strings "Log" do M4 
  if (now - lastStatusMsg >= 3000) {
      lastStatusMsg = now;
      if (HAL_HSEM_FastTake(HSEM_ID_SHARED_DATA) == HAL_OK) {
         if (!sharedData->hasMessage) {
            
            // Passa para char struct buffer protegido
            String log_msg = "Atualizando sensores...";
            log_msg.toCharArray((char*)sharedData->m4_message, 64);
            sharedData->hasMessage = true;
            
         }
         HAL_HSEM_Release(HSEM_ID_SHARED_DATA, 0);
      }
  }
}

#endif // CORE_CM4
